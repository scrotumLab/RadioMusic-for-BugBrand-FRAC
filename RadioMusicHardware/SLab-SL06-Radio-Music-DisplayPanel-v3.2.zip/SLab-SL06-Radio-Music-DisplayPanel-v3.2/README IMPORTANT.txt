This is a display panel with 3.2mm thick PCB.
15 units with blue soldermask on top layer only.
Please take care to prevent scratches and blemishes because this is used as display panel/frontpanel.
Please do not put any markings for manufacture in the top/front.
All holes are PLAIN/NOT PLATED.
